<?php 
    $current_route = trim($_SERVER['REQUEST_URI'], '/');
    $scriptName = trim(dirname($_SERVER['SCRIPT_NAME']), '/');
    if ($scriptName && strpos($current_route, $scriptName) === 0) {
        $current_route = trim(substr($current_route, strlen($scriptName)), '/');
    }
    if (($pos = strpos($current_route, '?')) !== false) {
        $current_route = substr($current_route, 0, $pos);
    }
    if ($current_route === '') $current_route = 'dashboard';
    $isDeptHead = Auth::isDepartmentHead();
    $isStaff = Auth::isStaff();
    $isVisitationTeam = Auth::isVisitationTeam();

    $churchName = AppConfig::getSetting('church_name', 'Church Management');
    $theme = AppConfig::getSetting('theme', 'dark');
    $theme = in_array($theme, ['dark', 'light'], true) ? $theme : 'dark';
    $logoRelativePath = Branding::getLogoPath();
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?php echo $theme; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Dashboard'; ?> | CMS Admin</title>
    <?php if ($logoRelativePath): ?>
        <link rel="icon" type="image/png" href="<?php echo BASE_URL . '/' . $logoRelativePath; ?>">
        <link rel="shortcut icon" href="<?php echo BASE_URL . '/' . $logoRelativePath; ?>">
    <?php endif; ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-dark: #0f172a; /* Blue-black */
            --primary-accent: #fbbf24; /* Yellow */
            --sidebar-bg: #020617;
            --card-glass: rgba(255, 255, 255, 0.03);
            --border-glass: rgba(255, 255, 255, 0.1);
            --text-color: #f8fafc;
            --body-bg: radial-gradient(circle at top right, #1e293b, #0f172a);
            --select-bg: rgba(2, 6, 23, 0.85);
            --select-text: #e2e8f0;
            --select-option-bg: #020617;
            --select-option-text: #e2e8f0;
        }

        html[data-theme="light"] {
            --sidebar-bg: rgba(255, 255, 255, 0.85);
            --card-glass: rgba(255, 255, 255, 0.78);
            --border-glass: rgba(15, 23, 42, 0.12);
            --text-color: #0f172a;
            --body-bg: radial-gradient(circle at top right, #ffffff, #f1f5f9);
            --select-bg: rgba(255, 255, 255, 0.95);
            --select-text: #0f172a;
            --select-option-bg: #ffffff;
            --select-option-text: #0f172a;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--body-bg);
            background-attachment: fixed;
            color: var(--text-color);
            min-height: 100vh;
        }

        /* Live Animated Gradient Background */
        .live-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            background: linear-gradient(125deg, #020617 0%, #0f172a 50%, #1e293b 100%);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
        }

        html[data-theme="light"] .live-bg {
            background: linear-gradient(125deg, #ffffff 0%, #f1f5f9 50%, #e2e8f0 100%);
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* 3D Floating Glass Objects */
        .glass-sphere {
            position: fixed;
            border-radius: 50%;
            background: radial-gradient(circle at 30% 30%, rgba(251, 191, 36, 0.15), rgba(251, 191, 36, 0.05));
            backdrop-filter: blur(40px);
            -webkit-backdrop-filter: blur(40px);
            border: 1px solid rgba(255, 255, 255, 0.05);
            z-index: -1;
            pointer-events: none;
            box-shadow: inset 0 0 40px rgba(251, 191, 36, 0.1), 0 20px 50px rgba(0, 0, 0, 0.2);
        }

        .sphere-1 {
            width: 400px;
            height: 400px;
            top: -100px;
            right: -100px;
            animation: float1 25s infinite alternate ease-in-out;
        }

        .sphere-2 {
            width: 300px;
            height: 300px;
            bottom: -50px;
            left: -50px;
            animation: float2 30s infinite alternate ease-in-out;
        }

        .sphere-3 {
            width: 200px;
            height: 200px;
            top: 40%;
            left: 20%;
            animation: float3 20s infinite alternate ease-in-out;
        }

        @keyframes float1 {
            0% { transform: translate(0, 0) rotate(0deg); }
            100% { transform: translate(-150px, 200px) rotate(360deg); }
        }

        @keyframes float2 {
            0% { transform: translate(0, 0) scale(1); }
            100% { transform: translate(200px, -150px) scale(1.2); }
        }

        @keyframes float3 {
            0% { transform: translate(0, 0) scale(1.2); }
            100% { transform: translate(100px, 100px) scale(0.8); }
        }

        .sidebar-gradient {
            background: var(--sidebar-bg);
            border-right: 1px solid var(--border-glass);
        }

        .active-link {
            background-color: var(--primary-accent);
            color: var(--primary-dark) !important;
            box-shadow: 0 0 20px rgba(251, 191, 36, 0.3);
        }

        .active-link i {
            color: var(--primary-dark) !important;
        }

        .glass-card {
            background: var(--card-glass);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid var(--border-glass);
        }

        select {
            background-color: var(--select-bg) !important;
            color: var(--select-text) !important;
        }
        select option {
            background-color: var(--select-option-bg) !important;
            color: var(--select-option-text) !important;
        }

        html[data-theme="light"] .text-white { color: #0f172a !important; }
        html[data-theme="light"] .text-slate-200 { color: #0f172a !important; }
        html[data-theme="light"] .text-slate-300 { color: #1f2937 !important; }
        html[data-theme="light"] .text-slate-400 { color: #334155 !important; }
        html[data-theme="light"] .text-slate-500 { color: #475569 !important; }
        html[data-theme="light"] .bg-white\\/5 { background-color: rgba(15, 23, 42, 0.06) !important; }
        html[data-theme="light"] .bg-white\\/10 { background-color: rgba(15, 23, 42, 0.08) !important; }
        html[data-theme="light"] .border-white\\/10 { border-color: rgba(15, 23, 42, 0.12) !important; }
        html[data-theme="light"] .border-white\\/5 { border-color: rgba(15, 23, 42, 0.10) !important; }
        html[data-theme="light"] .bg-slate-900,
        html[data-theme="light"] .bg-slate-900\/50,
        html[data-theme="light"] .bg-slate-950\/80,
        html[data-theme="light"] .bg-slate-950\/90 {
            background-color: rgba(255, 255, 255, 0.92) !important;
        }
        html[data-theme="light"] .card-interaction:hover {
            background: rgba(15, 23, 42, 0.03);
        }

        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: rgba(251, 191, 36, 0.2);
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: var(--primary-accent);
        }

        /* Typography & Utility */
        .text-accent { color: var(--primary-accent); }
        .bg-accent { background-color: var(--primary-accent); }

        /* Colorful Reusable Hovers */
        .hover-glow-yellow:hover {
            box-shadow: 0 0 25px rgba(251, 191, 36, 0.4);
            transform: translateY(-3px);
            border-color: rgba(251, 191, 36, 0.5) !important;
        }
        .hover-glow-blue:hover {
            box-shadow: 0 0 25px rgba(59, 130, 246, 0.4);
            transform: translateY(-3px);
            border-color: rgba(59, 130, 246, 0.5) !important;
        }
        .hover-glow-green:hover {
            box-shadow: 0 0 25px rgba(34, 197, 94, 0.4);
            transform: translateY(-3px);
            border-color: rgba(34, 197, 94, 0.5) !important;
        }
        .hover-glow-red:hover {
            box-shadow: 0 0 25px rgba(239, 68, 68, 0.4);
            transform: translateY(-3px);
            border-color: rgba(239, 68, 68, 0.5) !important;
        }
        .hover-glow-purple:hover {
            box-shadow: 0 0 25px rgba(168, 85, 247, 0.4);
            transform: translateY(-3px);
            border-color: rgba(168, 85, 247, 0.5) !important;
        }

        /* Sidebar Item Hover */
        .nav-item-hover {
            position: relative;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .nav-item-hover:hover:not(.active-link) {
            background: rgba(251, 191, 36, 0.05);
            padding-left: 1.5rem;
            color: var(--primary-accent) !important;
        }
        .nav-item-hover:hover i {
            color: var(--primary-accent) !important;
            transform: scale(1.2);
        }

        /* Card Scale Hover */
        .card-interaction {
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .card-interaction:hover {
            transform: translateY(-8px) scale(1.01);
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(251, 191, 36, 0.2);
        }

        .scroll-top-button {
            opacity: 0;
            pointer-events: none;
            transform: translateY(18px);
            transition: opacity 0.25s ease, transform 0.25s ease, box-shadow 0.25s ease;
        }

        .scroll-top-button.is-visible {
            opacity: 1;
            pointer-events: auto;
            transform: translateY(0);
        }

        .page-loader-overlay {
            position: fixed;
            inset: 0;
            z-index: 110;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
            background: rgba(2, 6, 23, 0.82);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            transition: opacity 0.25s ease, visibility 0.25s ease;
        }

        .page-loader-overlay.is-hidden {
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
        }

        .page-loader-card {
            width: min(100%, 24rem);
            border-radius: 1.75rem;
            border: 1px solid rgba(255, 255, 255, 0.12);
            background: rgba(15, 23, 42, 0.88);
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 30px 90px rgba(2, 6, 23, 0.45);
        }

        html[data-theme="light"] .page-loader-card {
            background: rgba(255, 255, 255, 0.92);
            border-color: rgba(15, 23, 42, 0.1);
        }

        .page-loader-spinner {
            width: 3.25rem;
            height: 3.25rem;
            margin: 0 auto 1rem;
            border-radius: 9999px;
            border: 4px solid rgba(255, 255, 255, 0.12);
            border-top-color: var(--primary-accent);
            animation: loaderSpin 0.8s linear infinite;
        }

        html[data-theme="light"] .page-loader-spinner {
            border-color: rgba(15, 23, 42, 0.12);
            border-top-color: var(--primary-accent);
        }

        .upload-progress-overlay {
            position: fixed;
            inset: 0;
            z-index: 115;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
            background: rgba(2, 6, 23, 0.88);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
        }

        .upload-progress-card {
            width: min(100%, 28rem);
            border-radius: 1.75rem;
            border: 1px solid rgba(255, 255, 255, 0.12);
            background: rgba(15, 23, 42, 0.94);
            padding: 1.5rem;
            box-shadow: 0 30px 90px rgba(2, 6, 23, 0.55);
        }

        html[data-theme="light"] .upload-progress-card {
            background: rgba(255, 255, 255, 0.96);
            border-color: rgba(15, 23, 42, 0.1);
        }

        .upload-progress-track {
            overflow: hidden;
            height: 0.9rem;
            width: 100%;
            border-radius: 9999px;
            background: rgba(255, 255, 255, 0.08);
        }

        html[data-theme="light"] .upload-progress-track {
            background: rgba(15, 23, 42, 0.08);
        }

        .upload-progress-bar {
            height: 100%;
            width: 0;
            border-radius: inherit;
            background: linear-gradient(90deg, #fbbf24 0%, #3b82f6 100%);
            box-shadow: 0 0 22px rgba(251, 191, 36, 0.4);
            transition: width 0.2s ease;
        }

        @keyframes loaderSpin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="text-gray-100">
    <div id="global-page-loader" class="page-loader-overlay" aria-live="polite">
        <div class="page-loader-card">
            <div class="page-loader-spinner"></div>
            <p id="global-page-loader-text" class="text-sm font-black uppercase tracking-[0.24em] text-accent">Loading</p>
            <p id="global-page-loader-subtext" class="mt-3 text-sm text-slate-300">Please wait while the page gets ready.</p>
        </div>
    </div>
    <div id="global-upload-progress" class="upload-progress-overlay hidden" aria-live="polite">
        <div class="upload-progress-card">
            <div class="flex items-center justify-between gap-4">
                <div>
                    <p class="text-[10px] font-black uppercase tracking-[0.26em] text-accent">Upload In Progress</p>
                    <p id="global-upload-progress-text" class="mt-2 text-sm font-bold text-slate-200">Uploading your file...</p>
                </div>
                <p id="global-upload-progress-percent" class="text-2xl font-black text-accent">0%</p>
            </div>
            <div class="upload-progress-track mt-5">
                <div id="global-upload-progress-bar" class="upload-progress-bar"></div>
            </div>
            <p id="global-upload-progress-subtext" class="mt-3 text-xs font-bold text-slate-400">Please do not close this page until the upload completes.</p>
        </div>
    </div>
    <div class="live-bg"></div>
    <!-- Floating Background Objects -->
    <div class="glass-sphere sphere-1"></div>
    <div class="glass-sphere sphere-2"></div>
    <div class="glass-sphere sphere-3"></div>
    
    <div class="relative flex min-h-screen lg:h-screen overflow-hidden">
        <div id="mobile-sidebar-overlay" class="fixed inset-0 z-30 hidden bg-slate-950/70 backdrop-blur-sm lg:hidden"></div>
        <!-- Sidebar -->
        <aside id="app-sidebar" class="fixed inset-y-0 left-0 z-40 flex w-72 max-w-[85vw] -translate-x-full flex-col sidebar-gradient text-white shadow-2xl transition-transform duration-300 lg:static lg:z-20 lg:w-64 lg:max-w-none lg:translate-x-0 lg:flex-shrink-0">
            <div class="flex items-center justify-between border-b border-white/5 p-6 lg:block lg:p-8">
                <button type="button" onclick="toggleSidebar(false)" class="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-slate-300 transition-all hover:bg-white/10 lg:hidden">
                    <i class="fas fa-times text-sm"></i>
                </button>
                <div class="hidden lg:block"></div>
            </div>
            <div class="px-6 pb-6 pt-2 lg:p-8 lg:pt-0 flex flex-col items-center border-b border-white/5">
                <div class="w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-xl shadow-yellow-500/20 overflow-hidden bg-transparent border border-white/10">
                    <?php if ($logoRelativePath): ?>
                        <img src="<?php echo BASE_URL . '/' . $logoRelativePath; ?>" alt="Logo" class="w-full h-full object-contain bg-transparent p-1">
                    <?php else: ?>
                        <div class="w-full h-full flex items-center justify-center bg-accent">
                            <i class="fas fa-church text-slate-900 text-3xl"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <span class="text-lg font-extrabold tracking-tight uppercase text-center"><?php echo $churchName; ?></span>
            </div>
            
            <nav class="flex-1 overflow-y-auto py-6 custom-scrollbar">
                <ul class="space-y-2 px-4">
                    <li>
                        <a href="<?php echo BASE_URL; ?>/dashboard" class="flex items-center px-5 py-3.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo ($current_route === 'dashboard') ? 'active-link' : 'text-slate-400'; ?>">
                            <i class="fas fa-th-large w-6 text-sm"></i>
                            <span class="ml-3 text-sm font-bold">Dashboard</span>
                        </a>
                    </li>
                    <?php if (!$isStaff && !$isVisitationTeam): ?>
                    <li>
                        <div class="flex items-center">
                            <a href="<?php echo BASE_URL; ?>/members" class="flex-1 flex items-center px-5 py-3.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'members') === 0 ? 'active-link' : 'text-slate-400'; ?>">
                                <i class="fas fa-users w-6 text-sm"></i>
                                <span class="ml-3 text-sm font-bold">Members</span>
                            </a>
                            <?php if (!$isDeptHead): ?>
                                <button type="button" onclick="toggleMembersSubmenu()" class="ml-2 w-10 h-10 flex items-center justify-center rounded-2xl bg-white/5 border border-white/10 text-slate-400 hover:bg-white/10 transition-all">
                                    <i id="members-chevron" class="fas fa-chevron-down text-[10px] transition-transform"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    </li>
                    <?php endif; ?>
                    <?php if (!$isDeptHead && !$isStaff && !$isVisitationTeam): ?>
                        <li>
                            <div id="members-submenu" class="<?php echo (strpos($current_route, 'cluster') === 0 || strpos($current_route, 'departments') === 0) ? '' : 'hidden'; ?>">
                                <a href="<?php echo BASE_URL; ?>/cluster" class="flex items-center px-5 py-2.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'cluster') === 0 ? 'active-link' : 'text-slate-400'; ?> ml-8">
                                    <i class="fas fa-layer-group w-6 text-[11px]"></i>
                                    <span class="ml-3 text-[11px] font-black uppercase tracking-widest">Groups</span>
                                </a>
                                <a href="<?php echo BASE_URL; ?>/departments" class="flex items-center px-5 py-2.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'departments') === 0 ? 'active-link' : 'text-slate-400'; ?> ml-8 mt-1">
                                    <i class="fas fa-sitemap w-6 text-[11px]"></i>
                                    <span class="ml-3 text-[11px] font-black uppercase tracking-widest">Departments</span>
                                </a>
                            </div>
                        </li>
                        <li>
                            <a href="<?php echo BASE_URL; ?>/attendance" class="flex items-center px-5 py-3.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'attendance') === 0 ? 'active-link' : 'text-slate-400'; ?>">
                                <i class="fas fa-check-square w-6 text-sm"></i>
                                <span class="ml-3 text-sm font-bold">Attendance</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (!$isVisitationTeam): ?>
                    <li>
                        <a href="<?php echo BASE_URL; ?>/finance" class="flex items-center px-5 py-3.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'finance') === 0 ? 'active-link' : 'text-slate-400'; ?>">
                            <i class="fas fa-wallet w-6 text-sm"></i>
                            <span class="ml-3 text-sm font-bold">Finance</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (!$isDeptHead && !$isStaff && !$isVisitationTeam): ?>
                        <li>
                            <a href="<?php echo BASE_URL; ?>/sms" class="flex items-center px-5 py-3.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'sms') === 0 ? 'active-link' : 'text-slate-400'; ?>">
                                <i class="fas fa-comment-dots w-6 text-sm"></i>
                                <span class="ml-3 text-sm font-bold">SMS Broadcast</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo BASE_URL; ?>/visitors" class="flex items-center px-5 py-3.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'visitors') === 0 ? 'active-link' : 'text-slate-400'; ?>">
                                <i class="fas fa-user-friends w-6 text-sm"></i>
                                <span class="ml-3 text-sm font-bold">Visitors</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo BASE_URL; ?>/reports" class="flex items-center px-5 py-3.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'reports') === 0 ? 'active-link' : 'text-slate-400'; ?>">
                                <i class="fas fa-chart-pie w-6 text-sm"></i>
                                <span class="ml-3 text-sm font-bold">Reports</span>
                            </a>
                        </li>
                        <li class="mt-8 pt-4 border-t border-white/5">
                            <a href="<?php echo BASE_URL; ?>/settings" class="flex items-center px-5 py-3.5 rounded-2xl nav-item-hover transition-all duration-300 <?php echo strpos($current_route, 'settings') === 0 ? 'active-link' : 'text-slate-400'; ?>">
                                <i class="fas fa-cog w-6 text-sm"></i>
                                <span class="ml-3 text-sm font-bold">Settings</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="border-b border-white/5 px-4 py-4 sm:px-6 sm:py-5 lg:px-10 lg:py-6">
                <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div class="flex items-center gap-3 sm:gap-4">
                        <button type="button" onclick="toggleSidebar(true)" class="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-slate-300 transition-all hover:bg-white/10 lg:hidden">
                            <i class="fas fa-bars text-sm"></i>
                        </button>
                        <h1 class="text-base sm:text-lg font-black tracking-tight uppercase text-accent"><?php echo $title ?? 'Dashboard'; ?></h1>
                    </div>
                    <div class="flex items-center justify-between gap-3 sm:justify-end sm:gap-4 lg:gap-6">
                        <div class="flex min-w-0 items-center space-x-3 rounded-2xl border border-white/10 bg-white/5 px-3 py-2 sm:px-4">
                            <span class="hidden truncate text-xs font-bold text-slate-300 sm:inline"><?php echo Session::get('user_name', 'Admin'); ?></span>
                            <span class="truncate text-[10px] font-black uppercase tracking-widest text-slate-400 sm:hidden">Profile</span>
                            <div class="w-8 h-8 bg-accent rounded-xl flex items-center justify-center overflow-hidden">
                                <?php if (Session::get('user_photo')): ?>
                                    <img src="<?php echo BASE_URL . '/' . Session::get('user_photo'); ?>" alt="Admin" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <i class="fas fa-user text-slate-900 text-xs"></i>
                                <?php endif; ?>
                            </div>
                        </div>
                        <a href="<?php echo BASE_URL; ?>/logout" class="w-10 h-10 inline-flex items-center justify-center rounded-2xl bg-white/5 text-slate-400 hover:bg-white/10 transition-all border border-white/10">
                            <i class="fas fa-right-from-bracket text-sm"></i>
                        </a>
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div id="app-scroll-container" class="flex-1 overflow-y-auto px-4 py-6 sm:px-6 sm:py-8 lg:px-10 lg:py-10 custom-scrollbar">
                <?php echo $content; ?>
            </div>
        </main>
    </div>
    <button
        type="button"
        id="scroll-top-button"
        class="scroll-top-button fixed bottom-5 right-4 sm:bottom-6 sm:right-6 lg:bottom-8 lg:right-10 z-30 inline-flex h-12 w-12 sm:h-14 sm:w-14 items-center justify-center rounded-2xl bg-accent text-slate-900 shadow-xl shadow-yellow-500/20 hover-glow-yellow"
        aria-label="Scroll to top"
    >
        <i class="fas fa-arrow-up text-sm"></i>
    </button>
    <script>
        (function () {
            const storageKey = 'membersSubmenuOpen';
            const submenu = document.getElementById('members-submenu');
            const chevron = document.getElementById('members-chevron');
            const sidebar = document.getElementById('app-sidebar');
            const overlay = document.getElementById('mobile-sidebar-overlay');
            const scrollContainer = document.getElementById('app-scroll-container');
            const scrollTopButton = document.getElementById('scroll-top-button');
            const pageLoader = document.getElementById('global-page-loader');
            const pageLoaderText = document.getElementById('global-page-loader-text');
            const pageLoaderSubtext = document.getElementById('global-page-loader-subtext');
            const uploadOverlay = document.getElementById('global-upload-progress');
            const uploadBar = document.getElementById('global-upload-progress-bar');
            const uploadPercent = document.getElementById('global-upload-progress-percent');
            const uploadText = document.getElementById('global-upload-progress-text');
            const uploadSubtext = document.getElementById('global-upload-progress-subtext');

            const showPageLoader = function (title, description) {
                if (!pageLoader) return;
                if (pageLoaderText && title) pageLoaderText.textContent = title;
                if (pageLoaderSubtext && description) pageLoaderSubtext.textContent = description;
                pageLoader.classList.remove('is-hidden');
            };

            const hidePageLoader = function () {
                if (!pageLoader) return;
                pageLoader.classList.add('is-hidden');
            };

            const showUploadOverlay = function (percentValue, title, description) {
                if (!uploadOverlay) return;
                const safePercent = Math.max(0, Math.min(100, Number(percentValue) || 0));
                if (uploadText && title) uploadText.textContent = title;
                if (uploadSubtext && description) uploadSubtext.textContent = description;
                if (uploadBar) uploadBar.style.width = safePercent + '%';
                if (uploadPercent) uploadPercent.textContent = safePercent + '%';
                uploadOverlay.classList.remove('hidden');
            };

            const hideUploadOverlay = function () {
                if (!uploadOverlay) return;
                uploadOverlay.classList.add('hidden');
            };

            const isUploadForm = function (form) {
                return (form.enctype || '').toLowerCase().includes('multipart/form-data')
                    && form.querySelector('input[type="file"]');
            };

            const hasSelectedUploadFile = function (form) {
                return Array.from(form.querySelectorAll('input[type="file"]')).some(function (input) {
                    return input.files && input.files.length > 0;
                });
            };

            const setFormSubmittingState = function (form, isSubmitting) {
                Array.from(form.querySelectorAll('button, input[type="submit"], input[type="button"]')).forEach(function (element) {
                    element.disabled = isSubmitting;
                });
            };

            const submitUploadForm = function (form, submitter) {
                if (!form.action || form.dataset.uploading === '1') return;

                form.dataset.uploading = '1';
                setFormSubmittingState(form, true);
                showUploadOverlay(0, 'Uploading your file...', 'Please wait while the upload finishes.');

                const formData = new FormData(form);
                if (submitter && submitter.name) {
                    formData.append(submitter.name, submitter.value || '');
                }

                const xhr = new XMLHttpRequest();
                xhr.open((form.method || 'POST').toUpperCase(), form.action, true);

                xhr.upload.addEventListener('progress', function (event) {
                    if (!event.lengthComputable) {
                        showUploadOverlay(35, 'Uploading your file...', 'Still uploading. Please keep this page open.');
                        return;
                    }
                    const percentValue = Math.max(1, Math.round((event.loaded / event.total) * 100));
                    showUploadOverlay(percentValue, 'Uploading your file...', 'Uploaded ' + percentValue + '%');
                });

                xhr.onload = function () {
                    hideUploadOverlay();
                    showPageLoader('Finishing Up', 'Finalizing the uploaded data and refreshing the page.');

                    if (xhr.status < 200 || xhr.status >= 400) {
                        form.dataset.uploading = '0';
                        setFormSubmittingState(form, false);
                        hidePageLoader();
                        alert('Upload failed. Please try again.');
                        return;
                    }

                    const responseUrl = xhr.responseURL || '';
                    const currentUrl = window.location.href;
                    const normalizedAction = new URL(form.action, currentUrl).href;

                    if (responseUrl && responseUrl !== normalizedAction) {
                        window.location.href = responseUrl;
                        return;
                    }

                    document.open();
                    document.write(xhr.responseText);
                    document.close();
                };

                xhr.onerror = xhr.onabort = function () {
                    form.dataset.uploading = '0';
                    setFormSubmittingState(form, false);
                    hideUploadOverlay();
                    hidePageLoader();
                    alert('Upload could not be completed. Please try again.');
                };

                xhr.send(formData);
            };

            const shouldShowLoaderForLink = function (link) {
                if (!link || link.dataset.skipLoader === '1') return false;
                const href = (link.getAttribute('href') || '').trim();
                if (!href || href === '#' || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return false;
                if (link.hasAttribute('download') || (link.target && link.target !== '_self')) return false;
                if (href.startsWith('#')) return false;
                return true;
            };

            window.addEventListener('load', function () {
                window.setTimeout(hidePageLoader, 120);
            });

            window.addEventListener('pageshow', function () {
                hidePageLoader();
                hideUploadOverlay();
            });

            document.addEventListener('click', function (event) {
                const link = event.target.closest('a');
                if (!shouldShowLoaderForLink(link)) return;
                showPageLoader('Loading Page', 'Please wait while the next page opens.');
            });

            document.addEventListener('submit', function (event) {
                const form = event.target;
                if (!(form instanceof HTMLFormElement)) return;

                if (isUploadForm(form) && hasSelectedUploadFile(form)) {
                    event.preventDefault();
                    submitUploadForm(form, event.submitter || document.activeElement);
                    return;
                }

                showPageLoader('Loading', 'Processing your request...');
            });

            window.toggleSidebar = function (open) {
                if (!sidebar || !overlay) return;
                const shouldOpen = open === undefined ? sidebar.classList.contains('-translate-x-full') : open;
                sidebar.classList.toggle('-translate-x-full', !shouldOpen);
                overlay.classList.toggle('hidden', !shouldOpen);
                document.body.classList.toggle('overflow-hidden', shouldOpen);
            };

            if (overlay) {
                overlay.addEventListener('click', function () {
                    window.toggleSidebar(false);
                });
            }

            window.addEventListener('resize', function () {
                if (window.innerWidth >= 1024) {
                    sidebar?.classList.remove('-translate-x-full');
                    overlay?.classList.add('hidden');
                    document.body.classList.remove('overflow-hidden');
                } else {
                    sidebar?.classList.add('-translate-x-full');
                    overlay?.classList.add('hidden');
                    document.body.classList.remove('overflow-hidden');
                }
            });

            const syncScrollTopButton = function () {
                if (!scrollTopButton) return;
                const currentPosition = scrollContainer ? scrollContainer.scrollTop : window.scrollY;
                scrollTopButton.classList.toggle('is-visible', currentPosition > 260);
            };

            if (scrollContainer) {
                scrollContainer.addEventListener('scroll', syncScrollTopButton, { passive: true });
            } else {
                window.addEventListener('scroll', syncScrollTopButton, { passive: true });
            }

            scrollTopButton?.addEventListener('click', function () {
                if (scrollContainer) {
                    scrollContainer.scrollTo({ top: 0, behavior: 'smooth' });
                    return;
                }
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });

            syncScrollTopButton();

            if (!submenu || !chevron) return;

            const route = <?php echo json_encode($current_route); ?>;
            const isChildActive = route.startsWith('cluster') || route.startsWith('departments');
            const saved = localStorage.getItem(storageKey);
            const shouldOpen = isChildActive || saved === '1';

            if (shouldOpen) submenu.classList.remove('hidden');
            chevron.classList.toggle('rotate-180', shouldOpen);

            window.toggleMembersSubmenu = function () {
                const isOpen = !submenu.classList.contains('hidden');
                if (isOpen) {
                    submenu.classList.add('hidden');
                    chevron.classList.remove('rotate-180');
                    localStorage.setItem(storageKey, '0');
                } else {
                    submenu.classList.remove('hidden');
                    chevron.classList.add('rotate-180');
                    localStorage.setItem(storageKey, '1');
                }
            }

        })();
    </script>
    <?php if (($current_route === 'dashboard') && Session::get('just_logged_in')): ?>
        <script>
            (function () {
                const name = <?php echo json_encode(Session::get('user_name', 'Admin')); ?>;
                const text = `Welcome ${name}.`;
                if (!('speechSynthesis' in window)) return;
                const u = new SpeechSynthesisUtterance(text);
                u.rate = 1;
                u.pitch = 1;
                u.volume = 1;
                window.speechSynthesis.cancel();
                window.speechSynthesis.speak(u);
            })();
        </script>
        <?php Session::remove('just_logged_in'); ?>
    <?php endif; ?>
</body>
</html>
