<?php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Finance.php';
require_once __DIR__ . '/../Models/Member.php';
require_once __DIR__ . '/../Models/Department.php';

class FinanceController extends BaseController {
    public function index() {
        $this->ensureFinanceSchema();
        $financeModel = new Finance();
        $deptModel = new Department();

        $isDeptHead = Auth::isDepartmentHead();
        $isStaff = Auth::isStaff();
        $myDeptId = $isDeptHead ? (int)(Session::get('user_department_id') ?? 0) : 0;
        if ($isDeptHead && $myDeptId <= 0) {
            Session::flash('error', 'Department access is not configured for this account.');
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
            header("Location: $base/dashboard");
            exit;
        }

        $month = (int)date('m');
        $year = (int)date('Y');
        $staffAllowedTypes = $this->getStaffAllowedTypes();
        $staffTotals = null;

        if ($isStaff) {
            $staffTotals = $financeModel->getRecorderTotals((int)Session::get('user_id'), $month, $year, $staffAllowedTypes);
            $monthlyIncome = (float)($staffTotals['month_total'] ?? 0);
            $monthlyExpenses = 0.0;
            $monthlyBalance = $monthlyIncome;
            $health = ((int)($staffTotals['transaction_count'] ?? 0)) > 0 ? 'Active' : 'Ready';
            $departmentSavings = [];
            $departmentHeadTotals = null;
            $recentTransactions = $financeModel->getRecentTransactionsByRecorderWithMeta((int)Session::get('user_id'), 50, $staffAllowedTypes);
        } else {
            $monthlyIncome = $financeModel->getMonthlyIncome($month, $year, $isDeptHead ? $myDeptId : null, null);
            $monthlyExpenses = $financeModel->getMonthlyExpenses($month, $year, $isDeptHead ? $myDeptId : null, null);
            $monthlyBalance = $monthlyIncome - $monthlyExpenses;
            $health = $monthlyBalance >= 0 ? 'Good' : 'Needs Review';
            $departmentSavings = $financeModel->getDepartmentSavingsSummary($month, $year, $isDeptHead ? $myDeptId : null, null);
            $departmentHeadTotals = $isDeptHead ? $financeModel->getDepartmentTotals($myDeptId, null) : null;
            $recentTransactions = $isDeptHead ? $financeModel->getRecentDepartmentTransactionsWithMeta($myDeptId, 50, null) : $financeModel->getRecentTransactionsWithMeta(50);
        }

        $db = Database::getInstance();
        $bank = [
            'bank_name' => $this->getSetting($db, 'finance_bank_name', ''),
            'account_name' => $this->getSetting($db, 'finance_account_name', ''),
            'account_number' => $this->getSetting($db, 'finance_account_number', ''),
            'branch' => $this->getSetting($db, 'finance_bank_branch', ''),
            'currency' => $this->getSetting($db, 'finance_currency', 'GHS')
        ];
        $departmentBank = null;
        if ($isDeptHead) {
            $departmentBank = $deptModel->getDepartmentBankDetails($myDeptId);
            if ($departmentBank) {
                $bank['bank_name'] = (string)($departmentBank['bank_name'] ?? '');
                $bank['account_name'] = (string)($departmentBank['account_name'] ?? '');
                $bank['account_number'] = (string)($departmentBank['account_number'] ?? '');
                $bank['branch'] = (string)($departmentBank['bank_branch'] ?? '');
            }
        }

        $membersForSelect = [];
        if (!$isDeptHead && !$isStaff) {
            $membersForSelect = $db->fetchAll("SELECT id, first_name, last_name FROM members ORDER BY first_name ASC, last_name ASC");
        }

        View::render('finance.index', [
            'title' => 'Financial Management',
            'overall_balance' => $isStaff ? (float)($staffTotals['overall_total'] ?? 0) : ($isDeptHead ? $monthlyBalance : $financeModel->getBalance()),
            'month' => $month,
            'year' => $year,
            'month_label' => date('F Y'),
            'health' => $health,
            'monthly_income' => $monthlyIncome,
            'monthly_expenses' => $monthlyExpenses,
            'monthly_balance' => $monthlyBalance,
            'department_head_totals' => $departmentHeadTotals,
            'department_savings' => $departmentSavings,
            'bank' => $bank,
            'department_bank' => $departmentBank,
            'recent_transactions' => $recentTransactions,
            'isDeptHead' => $isDeptHead,
            'isStaff' => $isStaff,
            'myDeptId' => $myDeptId,
            'membersForSelect' => $membersForSelect,
            'staff_totals' => $staffTotals,
            'staff_allowed_types' => $staffAllowedTypes,
            'receipt_data' => Session::flash('receipt_data')
        ]);
    }

    public function add() {
        $this->ensureFinanceSchema();
        $isDeptHead = Auth::isDepartmentHead();
        $isStaff = Auth::isStaff();
        $myDeptId = $isDeptHead ? (int)(Session::get('user_department_id') ?? 0) : 0;
        if ($isDeptHead && $myDeptId <= 0) {
            Session::flash('error', 'Department access is not configured for this account.');
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
            header("Location: $base/dashboard");
            exit;
        }
        $memberModel = new Member();
        $deptModel = new Department();
        $allowedTypes = $isStaff ? $this->getStaffAllowedTypes() : [];
        $defaultType = trim((string)($_GET['type'] ?? 'Offering'));
        if ($isStaff && !in_array($defaultType, $allowedTypes, true)) {
            $defaultType = 'Offering';
        }
        View::render('finance.add', [
            'title' => 'Record Transaction',
            'members' => $isDeptHead ? [] : $memberModel->all('first_name ASC'),
            'departments' => $isDeptHead ? $deptModel->where('id', $myDeptId) : $deptModel->all('name ASC'),
            'isDeptHead' => $isDeptHead,
            'isStaff' => $isStaff,
            'myDeptId' => $myDeptId,
            'staffAllowedTypes' => $allowedTypes,
            'defaultType' => $defaultType
        ]);
    }

    public function store() {
        $this->ensureFinanceSchema();
        $financeModel = new Finance();

        $isDeptHead = Auth::isDepartmentHead();
        $isStaff = Auth::isStaff();
        $myDeptId = $isDeptHead ? (int)(Session::get('user_department_id') ?? 0) : 0;
        if ($isDeptHead && $myDeptId <= 0) {
            Session::flash('error', 'Department access is not configured for this account.');
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
            header("Location: $base/dashboard");
            exit;
        }

        $db = Database::getInstance();
        $txNo = $this->generateTransactionNumber($db);

        $memberId = !empty($_POST['member_id']) ? (int)$_POST['member_id'] : null;
        $departmentId = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
        $transactionType = trim((string)($_POST['transaction_type'] ?? 'Offering'));
        $staffAllowedTypes = $this->getStaffAllowedTypes();
        $staffMemberTypes = ['Tithe', 'Welfare'];

        if ($isStaff && !in_array($transactionType, $staffAllowedTypes, true)) {
            Session::flash('error', 'Staff can record only general offering, tithe, department offering, and welfare transactions.');
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
            header("Location: $base/finance/add");
            exit;
        }

        if ($transactionType === 'Offering') {
            $memberId = null;
            $departmentId = null;
        } elseif ($departmentId) {
            $memberId = null;
        } elseif ($memberId) {
            $departmentId = null;
        }
        
        $data = [
            'transaction_number' => $txNo,
            'member_id' => $memberId,
            'department_id' => $departmentId,
            'transaction_type' => $transactionType,
            'amount' => $_POST['amount'],
            'payment_method' => $_POST['payment_method'],
            'transaction_date' => $_POST['transaction_date'],
            'description' => $_POST['description'],
            'reference_no' => $_POST['reference_no'],
            'recorded_by' => Session::get('user_id')
        ];

        $paymentMethod = trim((string)($_POST['payment_method'] ?? 'Cash'));
        if ($paymentMethod === 'Mobile Money') {
            $paymentMethod = 'MoMo';
        }

        if ($isDeptHead) {
            $data['member_id'] = null;
            $data['department_id'] = $myDeptId;
            $data['payment_method'] = $paymentMethod !== '' ? $paymentMethod : 'Cash';
        } elseif ($isStaff) {
            $data['payment_method'] = $paymentMethod !== '' ? $paymentMethod : 'Cash';
            if (in_array($transactionType, $staffMemberTypes, true)) {
                if (!$memberId) {
                    Session::flash('error', $transactionType . ' must be attached to a member.');
                    $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
                    header("Location: $base/finance/add?type=" . urlencode($transactionType));
                    exit;
                }
                $data['member_id'] = $memberId;
                $data['department_id'] = null;
            } elseif ($transactionType === 'Departmental Savings') {
                if (!$departmentId) {
                    Session::flash('error', 'Select a department for department offering.');
                    $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
                    header("Location: $base/finance/add?type=Departmental%20Savings");
                    exit;
                }
                $data['member_id'] = null;
                $data['department_id'] = $departmentId;
            } else {
                $data['member_id'] = null;
                $data['department_id'] = null;
            }
        } else {
            $data['payment_method'] = $paymentMethod !== '' ? $paymentMethod : 'Cash';
        }
        
        $financeId = $financeModel->create($data);
        
        if ($financeId) {
            AuditLog::log("Recorded " . $data['transaction_type'] . " of " . $data['amount'], "finances", $financeId);
            Session::flash('success', 'Transaction recorded successfully');
            if ($isStaff) {
                $receiptData = $financeModel->getTransactionWithMeta($financeId);
                if ($receiptData && (int)($receiptData['member_id'] ?? 0) > 0) {
                    Session::flash('receipt_data', $receiptData);
                }
            }
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
            header("Location: $base/finance");
        } else {
            Session::flash('error', 'Failed to record transaction');
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
            header("Location: $base/finance/add");
        }
        exit;
    }

    public function memberSummary() {
        $this->ensureFinanceSchema();
        $financeModel = new Finance();

        $memberId = (int)($_GET['member_id'] ?? 0);
        if ((Session::get('user_role') === 'dept_head')) {
            $myDeptId = (int)(Session::get('user_department_id') ?? 0);
            if ($myDeptId > 0) {
                $db = Database::getInstance();
                $row = $db->fetch("SELECT department_id FROM members WHERE id = ?", [$memberId]);
                if ((int)($row['department_id'] ?? 0) !== $myDeptId) {
                    header('Content-Type: application/json');
                    echo json_encode([
                        'member_id' => 0,
                        'income_total' => 0.0,
                        'expense_total' => 0.0,
                        'net_total' => 0.0,
                        'by_type' => []
                    ]);
                    exit;
                }
            }
        }
        $summary = $financeModel->getMemberTransactionSummary($memberId);

        header('Content-Type: application/json');
        echo json_encode($summary);
        exit;
    }

    public function memberTransactions() {
        $this->ensureFinanceSchema();
        $financeModel = new Finance();

        $memberId = (int)($_GET['member_id'] ?? 0);
        $limit = (int)($_GET['limit'] ?? 50);

        if ((Session::get('user_role') === 'dept_head')) {
            $myDeptId = (int)(Session::get('user_department_id') ?? 0);
            if ($myDeptId > 0) {
                $db = Database::getInstance();
                $row = $db->fetch("SELECT department_id FROM members WHERE id = ?", [$memberId]);
                if ((int)($row['department_id'] ?? 0) !== $myDeptId) {
                    header('Content-Type: application/json');
                    echo json_encode(['transactions' => []]);
                    exit;
                }
            }
        }

        $tx = $financeModel->getMemberTransactionsWithMeta($memberId, $limit);
        header('Content-Type: application/json');
        echo json_encode(['transactions' => $tx]);
        exit;
    }

    public function updateTransaction() {
        $this->ensureFinanceSchema();
        $financeModel = new Finance();

        $isDeptHead = (Session::get('user_role') === 'dept_head');
        $myDeptId = $isDeptHead ? (int)(Session::get('user_department_id') ?? 0) : 0;

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            Session::flash('error', 'Transaction ID missing.');
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
            header("Location: $base/finance");
            exit;
        }

        $tx = $financeModel->find($id);
        if (!$tx) {
            Session::flash('error', 'Transaction not found.');
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
            header("Location: $base/finance");
            exit;
        }

        if ($isDeptHead) {
            if ($myDeptId <= 0 || (int)($tx['department_id'] ?? 0) !== $myDeptId) {
                Session::flash('error', 'Unauthorized access.');
                $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
                header("Location: $base/finance");
                exit;
            }
        } else {
            $this->isAdmin();
        }

        $amount = (float)($_POST['amount'] ?? 0);
        $date = $_POST['transaction_date'] ?? null;
        $desc = $_POST['description'] ?? null;
        $ref = $_POST['reference_no'] ?? null;

        $financeModel->update($id, [
            'amount' => $amount,
            'transaction_date' => $date,
            'description' => $desc,
            'reference_no' => $ref,
            'recorded_by' => Session::get('user_id')
        ]);

        Session::flash('success', 'Transaction updated successfully.');
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
        header("Location: $base/finance");
        exit;
    }

    public function updateBankDetails() {
        $this->ensureFinanceSchema();
        $db = Database::getInstance();
        $isDeptHead = (Session::get('user_role') === 'dept_head');
        if (Auth::isStaff()) {
            $this->isAdmin();
        }
        if (!$isDeptHead) {
            $this->isAdmin();
        }
        $bankName = trim($_POST['finance_bank_name'] ?? '');
        $accountName = trim($_POST['finance_account_name'] ?? '');
        $accountNumber = trim($_POST['finance_account_number'] ?? '');
        $branch = trim($_POST['finance_bank_branch'] ?? '');
        $currency = strtoupper(trim($_POST['finance_currency'] ?? 'GHS'));
        if (!preg_match('/^[A-Z]{2,5}$/', $currency)) {
            $currency = 'GHS';
        }

        try {
            if ($isDeptHead) {
                $myDeptId = (int)(Session::get('user_department_id') ?? 0);
                if ($myDeptId <= 0) {
                    throw new Exception('Department access is not configured for this account.');
                }

                $db->query(
                    "UPDATE departments
                     SET bank_name = ?, account_name = ?, account_number = ?, bank_branch = ?
                     WHERE id = ?",
                    [$bankName, $accountName, $accountNumber, $branch, $myDeptId]
                );
                AuditLog::log("Updated department bank details", "departments", $myDeptId);
            } else {
                $this->upsertSetting($db, 'finance_bank_name', $bankName);
                $this->upsertSetting($db, 'finance_account_name', $accountName);
                $this->upsertSetting($db, 'finance_account_number', $accountNumber);
                $this->upsertSetting($db, 'finance_bank_branch', $branch);
                $this->upsertSetting($db, 'finance_currency', $currency);
                AuditLog::log("Updated finance bank details", "settings");
            }

            Session::flash('success', 'Bank details updated successfully');
        } catch (Exception $e) {
            Session::flash('error', 'Error updating bank details: ' . $e->getMessage());
        }

        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
        header("Location: $base/finance");
        exit;
    }

    private function ensureFinanceSchema() {
        $db = Database::getInstance();
        SchemaState::once('finance_schema', function () use ($db) {
            $columns = [
                'department_id' => "ALTER TABLE finances ADD COLUMN department_id INT NULL",
                'reference_no' => "ALTER TABLE finances ADD COLUMN reference_no VARCHAR(100) NULL",
                'recorded_by' => "ALTER TABLE finances ADD COLUMN recorded_by INT NULL",
                'transaction_number' => "ALTER TABLE finances ADD COLUMN transaction_number VARCHAR(50) NULL",
            ];

            foreach ($columns as $columnName => $alterSql) {
                if (!$db->columnExists('finances', $columnName)) {
                    $db->query($alterSql);
                }
            }

            if ($db->isMysql() && $db->getColumnDataType('finances', 'transaction_type') === 'enum') {
                $db->query("ALTER TABLE finances MODIFY COLUMN transaction_type VARCHAR(100) NULL");
            }

            if ($db->isMysql() && $db->getColumnDataType('finances', 'payment_method') === 'enum') {
                $db->query("ALTER TABLE finances MODIFY COLUMN payment_method VARCHAR(50) NULL");
            }

            $db->query(
                "UPDATE finances
                 SET transaction_type = CASE
                        WHEN transaction_type IS NOT NULL AND transaction_type <> '' THEN transaction_type
                        WHEN category IS NOT NULL AND category <> '' THEN category
                        WHEN department_id IS NOT NULL THEN 'Departmental Savings'
                        ELSE 'Offering'
                     END
                 WHERE transaction_type IS NULL OR transaction_type = ''"
            );

            $db->query(
                "UPDATE finances
                 SET payment_method = CASE
                        WHEN payment_method IS NOT NULL AND payment_method <> '' THEN payment_method
                        WHEN LOWER(COALESCE(subcategory, '')) IN ('cash', 'momo', 'mobile money', 'bank transfer', 'bank_transfer', 'check') THEN
                            CASE LOWER(COALESCE(subcategory, ''))
                                WHEN 'mobile money' THEN 'MoMo'
                                WHEN 'momo' THEN 'MoMo'
                                WHEN 'bank_transfer' THEN 'Bank Transfer'
                                WHEN 'bank transfer' THEN 'Bank Transfer'
                                WHEN 'check' THEN 'Check'
                                ELSE 'Cash'
                            END
                        ELSE 'Cash'
                     END
                 WHERE payment_method IS NULL OR payment_method = ''"
            );

            $db->query(
                "UPDATE finances
                 SET payment_method = CASE LOWER(COALESCE(payment_method, ''))
                        WHEN 'cash' THEN 'Cash'
                        WHEN 'momo' THEN 'MoMo'
                        WHEN 'mobile money' THEN 'MoMo'
                        WHEN 'bank_transfer' THEN 'Bank Transfer'
                        WHEN 'bank transfer' THEN 'Bank Transfer'
                        WHEN 'check' THEN 'Check'
                        ELSE payment_method
                     END"
            );

            $departmentColumns = [
                'bank_name' => "ALTER TABLE departments ADD COLUMN bank_name VARCHAR(120) NULL",
                'account_name' => "ALTER TABLE departments ADD COLUMN account_name VARCHAR(120) NULL",
                'account_number' => "ALTER TABLE departments ADD COLUMN account_number VARCHAR(80) NULL",
                'bank_branch' => "ALTER TABLE departments ADD COLUMN bank_branch VARCHAR(120) NULL"
            ];

            foreach ($departmentColumns as $columnName => $alterSql) {
                if (!$db->columnExists('departments', $columnName)) {
                    $db->query($alterSql);
                }
            }
        });
    }

    private function getStaffAllowedTypes() {
        return ['Offering', 'Tithe', 'Departmental Savings', 'Welfare'];
    }

    private function generateTransactionNumber($db) {
        for ($i = 0; $i < 5; $i++) {
            $candidate = 'TX' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(6)), 0, 12));
            try {
                $row = $db->fetch("SELECT id FROM finances WHERE transaction_number = ? LIMIT 1", [$candidate]);
                if (!$row) return $candidate;
            } catch (Exception $e) {
                return $candidate;
            }
        }
        return 'TX' . date('YmdHis') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    }

    private function getSetting($db, $key, $default = '') {
        $row = $db->fetch("SELECT value FROM settings WHERE key_name = ?", [$key]);
        if ($row && array_key_exists('value', $row) && $row['value'] !== null) {
            return (string)$row['value'];
        }
        return $default;
    }

    private function upsertSetting($db, $key, $value) {
        $exists = $db->fetch("SELECT id FROM settings WHERE key_name = ?", [$key]);
        if ($exists) {
            $db->query("UPDATE settings SET value = ? WHERE key_name = ?", [$value, $key]);
        } else {
            $db->query("INSERT INTO settings (key_name, value) VALUES (?, ?)", [$key, $value]);
        }
        AppConfig::reset();
    }
}
