<?php 
    $churchName = AppConfig::getSetting('church_name', 'Church Management');
    $theme = AppConfig::getSetting('theme', 'dark');
    $theme = in_array($theme, ['dark', 'light'], true) ? $theme : 'dark';
    $logoRelativePath = Branding::getLogoPath();
    $mode = isset($mode) ? (string)$mode : 'login';
    $token = isset($token) ? (string)$token : (string)($_GET['token'] ?? '');
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?php echo $theme; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Administrator Login | <?php echo $churchName; ?></title>
    <?php if ($logoRelativePath): ?>
        <link rel="icon" type="image/png" href="<?php echo BASE_URL . '/' . $logoRelativePath; ?>">
        <link rel="shortcut icon" href="<?php echo BASE_URL . '/' . $logoRelativePath; ?>">
    <?php endif; ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        .mesh-gradient {
            background-color: #0f172a; /* Match main theme */
            background-image: 
                radial-gradient(at 0% 0%, hsla(161, 84%, 15%, 1) 0, transparent 50%), 
                radial-gradient(at 100% 0%, hsla(158, 84%, 10%, 1) 0, transparent 50%), 
                radial-gradient(at 100% 100%, hsla(160, 84%, 5%, 1) 0, transparent 50%), 
                radial-gradient(at 0% 100%, hsla(162, 84%, 12%, 1) 0, transparent 50%);
        }
        html[data-theme="light"] .mesh-gradient {
            background-color: #ffffff;
            background-image:
                radial-gradient(at 0% 0%, rgba(241, 245, 249, 1) 0, transparent 55%),
                radial-gradient(at 100% 0%, rgba(226, 232, 240, 1) 0, transparent 55%),
                radial-gradient(at 100% 100%, rgba(241, 245, 249, 1) 0, transparent 55%),
                radial-gradient(at 0% 100%, rgba(226, 232, 240, 1) 0, transparent 55%);
        }
        .login-shell {
            position: relative;
        }
        .login-shell::before {
            content: "";
            position: absolute;
            inset: -18px;
            border-radius: 2.8rem;
            background: linear-gradient(135deg, rgba(251, 191, 36, 0.14), rgba(59, 130, 246, 0.1), rgba(255, 255, 255, 0.04));
            filter: blur(18px);
            z-index: 0;
        }
        .login-card {
            position: relative;
            background: linear-gradient(180deg, rgba(15, 23, 42, 0.82), rgba(15, 23, 42, 0.72));
            backdrop-filter: blur(26px);
            -webkit-backdrop-filter: blur(26px);
            box-shadow: 0 35px 80px -18px rgba(2, 6, 23, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        html[data-theme="light"] .login-card {
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.9), rgba(248, 250, 252, 0.82));
            border: 1px solid rgba(15, 23, 42, 0.12);
            box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.18);
        }
        .glass-panel {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.08);
        }
        html[data-theme="light"] .glass-panel {
            background: rgba(255, 255, 255, 0.68);
            border: 1px solid rgba(15, 23, 42, 0.08);
        }
        html[data-theme="light"] .text-white { color: #0f172a !important; }
        html[data-theme="light"] .text-red-200 { color: #991b1b !important; }
        .input-focus:focus {
            box-shadow: 0 0 0 4px rgba(251, 191, 36, 0.15);
        }
        .btn-gradient {
            background: linear-gradient(135deg, #fbbf24 0%, #d97706 100%);
            box-shadow: 0 18px 40px -18px rgba(251, 191, 36, 0.8);
        }
        .login-card::after {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: inherit;
            pointer-events: none;
            background: linear-gradient(135deg, rgba(255,255,255,0.14), transparent 28%, transparent 72%, rgba(255,255,255,0.05));
        }
        #login_type {
            background-color: #020617 !important;
            color: #f8fafc !important;
            color-scheme: dark;
        }
        #login_type option {
            background-color: #020617 !important;
            color: #f8fafc !important;
        }

        .orange-glow {
            position: fixed;
            border-radius: 9999px;
            background: radial-gradient(circle at 30% 30%, rgba(249, 115, 22, 0.22), rgba(249, 115, 22, 0.06));
            filter: blur(0px);
            border: 1px solid rgba(249, 115, 22, 0.10);
            box-shadow: inset 0 0 30px rgba(249, 115, 22, 0.10), 0 35px 80px rgba(0, 0, 0, 0.25);
            z-index: 0;
            pointer-events: none;
            backdrop-filter: blur(35px);
            -webkit-backdrop-filter: blur(35px);
        }

        .orange-glow-1 {
            width: 420px;
            height: 420px;
            top: -140px;
            right: -140px;
            animation: floatOrange1 22s ease-in-out infinite alternate;
        }

        .orange-glow-2 {
            width: 320px;
            height: 320px;
            bottom: -120px;
            left: -120px;
            animation: floatOrange2 26s ease-in-out infinite alternate;
        }

        .orange-glow-3 {
            width: 260px;
            height: 260px;
            top: 40%;
            left: 60%;
            transform: translate(-50%, -50%);
            animation: floatOrange3 18s ease-in-out infinite alternate;
        }
        .blue-glow {
            position: fixed;
            border-radius: 9999px;
            background: radial-gradient(circle at 30% 30%, rgba(59, 130, 246, 0.22), rgba(59, 130, 246, 0.05));
            border: 1px solid rgba(96, 165, 250, 0.18);
            box-shadow: inset 0 0 32px rgba(96, 165, 250, 0.12), 0 35px 90px rgba(2, 6, 23, 0.25);
            z-index: 0;
            pointer-events: none;
            backdrop-filter: blur(35px);
            -webkit-backdrop-filter: blur(35px);
        }
        .blue-glow-1 {
            width: 300px;
            height: 300px;
            top: 14%;
            left: 8%;
            animation: floatBlue1 20s ease-in-out infinite alternate;
        }

        @keyframes floatOrange1 {
            0% { transform: translate(0, 0) scale(1); }
            100% { transform: translate(-60px, 80px) scale(1.08); }
        }
        @keyframes floatOrange2 {
            0% { transform: translate(0, 0) scale(1); }
            100% { transform: translate(90px, -70px) scale(1.06); }
        }
        @keyframes floatOrange3 {
            0% { transform: translate(-50%, -50%) scale(1); opacity: 0.8; }
            100% { transform: translate(calc(-50% - 80px), calc(-50% + 60px)) scale(1.1); opacity: 1; }
        }
        @keyframes floatBlue1 {
            0% { transform: translate(0, 0) scale(1); opacity: 0.78; }
            100% { transform: translate(70px, 40px) scale(1.12); opacity: 1; }
        }
        .page-shell {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 1180px;
        }
        .brand-panel {
            position: relative;
            overflow: hidden;
            background: linear-gradient(180deg, rgba(15, 23, 42, 0.58), rgba(15, 23, 42, 0.28));
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: 0 30px 80px -35px rgba(2, 6, 23, 0.85);
        }
        html[data-theme="light"] .brand-panel {
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.84), rgba(248, 250, 252, 0.72));
            border: 1px solid rgba(15, 23, 42, 0.1);
            box-shadow: 0 24px 50px -30px rgba(15, 23, 42, 0.25);
        }
        .stat-chip {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.06);
        }
        html[data-theme="light"] .stat-chip {
            background: rgba(255, 255, 255, 0.75);
            border-color: rgba(15, 23, 42, 0.08);
        }
        .feature-tile {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        html[data-theme="light"] .feature-tile {
            background: rgba(255, 255, 255, 0.7);
            border-color: rgba(15, 23, 42, 0.08);
        }
        @media (max-width: 767px) {
            .orange-glow-1 {
                width: 240px;
                height: 240px;
                top: -80px;
                right: -80px;
            }
            .orange-glow-2 {
                width: 220px;
                height: 220px;
                bottom: -70px;
                left: -70px;
            }
            .orange-glow-3 {
                width: 170px;
                height: 170px;
                top: 48%;
                left: 72%;
            }
            .blue-glow-1 {
                width: 190px;
                height: 190px;
                top: 10%;
                left: -30px;
            }
        }

        .page-loader-overlay {
            position: fixed;
            inset: 0;
            z-index: 120;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1.5rem;
            background: rgba(2, 6, 23, 0.82);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            transition: opacity 0.25s ease, visibility 0.25s ease;
        }

        .page-loader-overlay.is-hidden {
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
        }

        .page-loader-card {
            width: min(100%, 24rem);
            border-radius: 1.75rem;
            border: 1px solid rgba(255, 255, 255, 0.12);
            background: rgba(15, 23, 42, 0.9);
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 30px 90px rgba(2, 6, 23, 0.45);
        }

        html[data-theme="light"] .page-loader-card {
            background: rgba(255, 255, 255, 0.94);
            border-color: rgba(15, 23, 42, 0.1);
        }

        .page-loader-spinner {
            width: 3.25rem;
            height: 3.25rem;
            margin: 0 auto 1rem;
            border-radius: 9999px;
            border: 4px solid rgba(255, 255, 255, 0.12);
            border-top-color: #fbbf24;
            animation: authLoaderSpin 0.8s linear infinite;
        }

        html[data-theme="light"] .page-loader-spinner {
            border-color: rgba(15, 23, 42, 0.12);
            border-top-color: #fbbf24;
        }

        @keyframes authLoaderSpin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="mesh-gradient min-h-screen flex items-center justify-center px-4 py-6 sm:px-6 sm:py-10 lg:px-8">
    <div id="auth-page-loader" class="page-loader-overlay" aria-live="polite">
        <div class="page-loader-card">
            <div class="page-loader-spinner"></div>
            <p id="auth-page-loader-text" class="text-sm font-black uppercase tracking-[0.24em] text-amber-300">Loading</p>
            <p id="auth-page-loader-subtext" class="mt-3 text-sm text-slate-300">Please wait while the page gets ready.</p>
        </div>
    </div>
    <div class="blue-glow blue-glow-1"></div>
    <div class="orange-glow orange-glow-1"></div>
    <div class="orange-glow orange-glow-2"></div>
    <div class="orange-glow orange-glow-3"></div>
    <div class="page-shell">
        <div class="grid items-start gap-6 lg:grid-cols-[minmax(0,1.08fr)_minmax(420px,520px)] lg:gap-8">
            <section class="brand-panel rounded-[2.4rem] p-6 sm:p-8 lg:p-10">
                <div class="flex items-start justify-between gap-4">
                    <div class="inline-flex items-center gap-4">
                        <div class="inline-flex items-center justify-center w-16 h-16 sm:w-20 sm:h-20 bg-white/10 backdrop-blur-md rounded-[1.6rem] border border-white/20 shadow-xl overflow-hidden shrink-0">
                            <?php if ($logoRelativePath): ?>
                                <img src="<?php echo BASE_URL . '/' . $logoRelativePath; ?>" alt="Logo" class="w-full h-full object-contain bg-transparent p-1.5">
                            <?php else: ?>
                                <i class="fas fa-church text-2xl text-amber-300"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <p class="text-[10px] sm:text-[11px] font-black uppercase tracking-[0.34em] text-amber-300/90">Secure Church Portal</p>
                            <h1 class="mt-3 text-2xl sm:text-3xl lg:text-[2.5rem] font-black text-white tracking-tight uppercase leading-tight"><?php echo $churchName; ?></h1>
                        </div>
                    </div>
                    <span class="hidden sm:inline-flex items-center rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.28em] text-slate-300">
                        Upper Room
                    </span>
                </div>

                <div class="mt-8 sm:mt-10 max-w-xl">
                    <p class="text-sm sm:text-base text-slate-300 font-semibold leading-7">
                        A polished access point for administrators, department heads, and staff with responsive glassmorphism panels, secure sign-in, and a layout that stays clean on every screen.
                    </p>
                </div>

                <div class="mt-8 grid gap-3 sm:grid-cols-3">
                    <div class="stat-chip rounded-[1.5rem] p-4">
                        <p class="text-[10px] font-black uppercase tracking-[0.26em] text-slate-500">Portal Mode</p>
                        <p class="mt-2 text-sm font-bold text-white">Role-based access</p>
                    </div>
                    <div class="stat-chip rounded-[1.5rem] p-4">
                        <p class="text-[10px] font-black uppercase tracking-[0.26em] text-slate-500">Experience</p>
                        <p class="mt-2 text-sm font-bold text-white">Mobile to desktop</p>
                    </div>
                    <div class="stat-chip rounded-[1.5rem] p-4">
                        <p class="text-[10px] font-black uppercase tracking-[0.26em] text-slate-500">Security</p>
                        <p class="mt-2 text-sm font-bold text-white">Protected sessions</p>
                    </div>
                </div>

                <div class="mt-8 grid gap-3 sm:grid-cols-2">
                    <div class="feature-tile rounded-[1.7rem] p-5">
                        <div class="w-11 h-11 rounded-2xl bg-amber-400/10 border border-amber-300/20 text-amber-300 flex items-center justify-center">
                            <i class="fas fa-shield-halved"></i>
                        </div>
                        <h3 class="mt-4 text-sm font-black text-white uppercase tracking-[0.18em]">Trusted Access</h3>
                        <p class="mt-2 text-sm text-slate-400 leading-6">Separate sign-in levels for admin, department head, and staff with a cleaner guided form layout.</p>
                    </div>
                    <div class="feature-tile rounded-[1.7rem] p-5">
                        <div class="w-11 h-11 rounded-2xl bg-blue-500/10 border border-blue-400/20 text-blue-300 flex items-center justify-center">
                            <i class="fas fa-mobile-screen-button"></i>
                        </div>
                        <h3 class="mt-4 text-sm font-black text-white uppercase tracking-[0.18em]">Responsive UI</h3>
                        <p class="mt-2 text-sm text-slate-400 leading-6">Balanced spacing, wider desktop presentation, and stacked mobile sections for a better first impression.</p>
                    </div>
                </div>
            </section>

            <div class="login-shell">
                <div class="login-card rounded-[2.4rem] overflow-hidden border border-white/5">
                    <div class="relative p-6 sm:p-8 lg:p-10">
                        <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between mb-8 sm:mb-10">
                            <div>
                                <h2 class="text-3xl sm:text-[2.2rem] font-black text-white tracking-tighter leading-tight">
                                    <?php echo $mode === 'forgot' ? 'Forgot Password' : ($mode === 'reset' ? 'Reset Password' : 'Sign In'); ?>
                                </h2>
                                <p class="text-slate-400 text-[11px] font-bold uppercase tracking-[0.24em] mt-3">
                                    <?php echo $mode === 'forgot' ? 'Recover account access' : ($mode === 'reset' ? 'Set your new password' : 'Sign in first to continue'); ?>
                                </p>
                            </div>
                            <span class="inline-flex w-fit items-center rounded-full border border-amber-300/20 bg-amber-400/10 px-3 py-1.5 text-[10px] font-black uppercase tracking-[0.26em] text-amber-300 shadow-lg shadow-yellow-500/10">
                                <i class="fas fa-shield-halved mr-2"></i> Secure
                            </span>
                        </div>

                        <?php if ($success = Session::flash('success')): ?>
                            <div class="bg-emerald-500/10 border border-emerald-500/20 p-4 mb-8 rounded-2xl flex items-start space-x-3">
                                <i class="fas fa-circle-check text-emerald-400 mt-1"></i>
                                <p class="text-xs text-emerald-200 font-bold"><?php echo $success; ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if ($error = Session::flash('error')): ?>
                            <div class="bg-red-500/10 border border-red-500/20 p-4 mb-8 rounded-2xl flex items-start space-x-3">
                                <i class="fas fa-circle-exclamation text-red-400 mt-1"></i>
                                <p class="text-xs text-red-200 font-bold"><?php echo $error; ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if ($mode === 'forgot'): ?>
                            <form action="<?php echo BASE_URL; ?>/forgot-password" method="POST" class="space-y-6 relative z-10">
                                <div class="glass-panel rounded-[2rem] p-5 sm:p-6 space-y-6">
                                    <div class="rounded-2xl bg-white/[0.03] border border-white/10 px-4 py-3">
                                        <p class="text-[10px] font-black uppercase tracking-[0.22em] text-slate-500">Account Recovery</p>
                                        <p class="text-xs font-bold text-slate-300 mt-1">Enter your username or email to generate a password reset link.</p>
                                    </div>

                                    <div class="space-y-2">
                                        <label for="login" class="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Username or Email</label>
                                        <div class="relative group">
                                            <div class="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                                                <i class="fas fa-user text-slate-600 group-focus-within:text-amber-300 transition-colors"></i>
                                            </div>
                                            <input type="text" id="login" name="login" required
                                                class="block w-full pl-12 pr-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm font-bold placeholder-slate-600 focus:bg-white/10 focus:border-amber-300 focus:outline-none transition-all input-focus"
                                                placeholder="username or email">
                                        </div>
                                        <p class="text-[10px] font-bold text-slate-400 mt-3">A reset link will be generated on this page.</p>
                                    </div>
                                </div>

                                <?php if ($resetLink = Session::flash('reset_link')): ?>
                                    <div class="bg-white/5 border border-white/10 p-4 rounded-2xl">
                                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Reset Link</p>
                                        <div class="flex flex-col gap-2 sm:flex-row">
                                            <input id="reset_link" type="text" readonly value="<?php echo htmlspecialchars($resetLink); ?>"
                                                class="flex-1 bg-slate-950/30 border border-white/10 rounded-xl px-4 py-3 text-[11px] font-bold text-slate-200 outline-none">
                                            <button type="button" onclick="copyResetLink()" class="px-4 py-3 rounded-xl bg-amber-400 text-slate-900 text-[10px] font-black uppercase tracking-widest">Copy</button>
                                        </div>
                                        <a href="<?php echo htmlspecialchars($resetLink); ?>" class="inline-flex items-center text-[10px] font-black uppercase tracking-widest text-amber-300 mt-4 hover:underline">
                                            Open reset page <i class="fas fa-arrow-right ml-2"></i>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <button type="submit"
                                    class="w-full btn-gradient text-slate-900 py-4.5 px-6 rounded-2xl font-black text-xs uppercase tracking-[0.2em] hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl shadow-yellow-500/10">
                                    Generate Reset Link
                                </button>

                                <div class="text-center pt-2">
                                    <a href="<?php echo BASE_URL; ?>/login" class="text-[10px] text-amber-300 hover:text-white font-black uppercase tracking-widest transition-colors">Back to login</a>
                                </div>
                            </form>
                        <?php elseif ($mode === 'reset'): ?>
                            <form action="<?php echo BASE_URL; ?>/reset-password" method="POST" class="space-y-6 relative z-10">
                                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">

                                <div class="glass-panel rounded-[2rem] p-5 sm:p-6 space-y-6">
                                    <div class="rounded-2xl bg-white/[0.03] border border-white/10 px-4 py-3">
                                        <p class="text-[10px] font-black uppercase tracking-[0.22em] text-slate-500">New Password</p>
                                        <p class="text-xs font-bold text-slate-300 mt-1">Create a strong password and confirm it to complete account recovery.</p>
                                    </div>

                                    <div class="space-y-2">
                                        <label for="password" class="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">New Password</label>
                                        <div class="relative group">
                                            <div class="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                                                <i class="fas fa-lock text-slate-600 group-focus-within:text-amber-300 transition-colors"></i>
                                            </div>
                                            <input type="password" id="password" name="password" required
                                                class="block w-full pl-12 pr-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm font-bold placeholder-slate-600 focus:bg-white/10 focus:border-amber-300 focus:outline-none transition-all input-focus"
                                                placeholder="••••••••">
                                        </div>
                                    </div>

                                    <div class="space-y-2">
                                        <label for="confirm_password" class="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Confirm Password</label>
                                        <div class="relative group">
                                            <div class="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                                                <i class="fas fa-lock text-slate-600 group-focus-within:text-amber-300 transition-colors"></i>
                                            </div>
                                            <input type="password" id="confirm_password" name="confirm_password" required
                                                class="block w-full pl-12 pr-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm font-bold placeholder-slate-600 focus:bg-white/10 focus:border-amber-300 focus:outline-none transition-all input-focus"
                                                placeholder="••••••••">
                                        </div>
                                    </div>
                                </div>

                                <button type="submit"
                                    class="w-full btn-gradient text-slate-900 py-4.5 px-6 rounded-2xl font-black text-xs uppercase tracking-[0.2em] hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl shadow-yellow-500/10">
                                    Update Password
                                </button>

                                <div class="text-center pt-2 flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4">
                                    <a href="<?php echo BASE_URL; ?>/forgot-password" class="text-[10px] text-amber-300 hover:text-white font-black uppercase tracking-widest transition-colors">New reset link</a>
                                    <span class="hidden sm:inline text-slate-600">|</span>
                                    <a href="<?php echo BASE_URL; ?>/login" class="text-[10px] text-amber-300 hover:text-white font-black uppercase tracking-widest transition-colors">Back to login</a>
                                </div>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo BASE_URL; ?>/login" method="POST" class="space-y-6 relative z-10">
                                <div class="glass-panel rounded-[2rem] p-5 sm:p-6 space-y-6">
                                    <div class="flex items-center justify-between gap-4 rounded-2xl bg-white/[0.03] border border-white/10 px-4 py-3">
                                        <div>
                                            <p class="text-[10px] font-black uppercase tracking-[0.22em] text-slate-500">Login Access</p>
                                            <p class="text-xs font-bold text-slate-300 mt-1">Choose your account level and continue securely.</p>
                                        </div>
                                        <div class="w-11 h-11 rounded-2xl bg-blue-500/10 border border-blue-400/20 text-blue-300 flex items-center justify-center shrink-0">
                                            <i class="fas fa-user-shield"></i>
                                        </div>
                                    </div>

                                    <div class="space-y-2">
                                        <label for="login" class="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Username</label>
                                        <div class="relative group">
                                            <div class="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                                                <i class="fas fa-user text-slate-600 group-focus-within:text-amber-300 transition-colors"></i>
                                            </div>
                                            <input type="text" id="login" name="login" required
                                                class="block w-full pl-12 pr-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm font-bold placeholder-slate-600 focus:bg-white/10 focus:border-amber-300 focus:outline-none transition-all input-focus"
                                                placeholder="username or email">
                                        </div>
                                    </div>

                                    <div class="space-y-2">
                                        <div class="flex items-center justify-between ml-1 gap-3">
                                            <label for="password" class="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Password</label>
                                            <a href="<?php echo BASE_URL; ?>/forgot-password" class="text-[10px] text-amber-300 hover:text-white font-black uppercase tracking-widest transition-colors">Forgot?</a>
                                        </div>
                                        <div class="relative group">
                                            <div class="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                                                <i class="fas fa-lock text-slate-600 group-focus-within:text-amber-300 transition-colors"></i>
                                            </div>
                                            <input type="password" id="password" name="password" required
                                                class="block w-full pl-12 pr-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm font-bold placeholder-slate-600 focus:bg-white/10 focus:border-amber-300 focus:outline-none transition-all input-focus"
                                                placeholder="••••••••">
                                        </div>
                                    </div>

                                    <div class="grid gap-5 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
                                        <div class="space-y-2">
                                            <label for="login_type" class="block text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Permission Level</label>
                                            <div class="relative group">
                                                <div class="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
                                                    <i class="fas fa-id-badge text-slate-600 group-focus-within:text-amber-300 transition-colors"></i>
                                                </div>
                                                <select id="login_type" name="login_type" class="block w-full pl-12 pr-10 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm font-bold focus:bg-white/10 focus:border-amber-300 focus:outline-none transition-all input-focus appearance-none">
                                                    <option value="admin">Admin</option>
                                                    <option value="dept_head">Department Head</option>
                                                    <option value="visitation_team">Visitation Team</option>
                                                    <option value="staff" selected>Staff</option>
                                                </select>
                                                <div class="absolute inset-y-0 right-0 pr-5 flex items-center pointer-events-none">
                                                    <i class="fas fa-chevron-down text-slate-600 text-[10px]"></i>
                                                </div>
                                            </div>
                                        </div>

                                        <label class="relative flex items-center cursor-pointer group min-h-[56px] rounded-2xl border border-white/10 bg-white/[0.03] px-4">
                                            <input type="checkbox" id="remember" name="remember" class="sr-only peer">
                                            <div class="relative w-10 h-5 rounded-full bg-white/10 transition-colors peer-checked:bg-amber-400/90 after:content-[''] after:absolute after:left-[2px] after:top-[2px] after:h-4 after:w-4 after:rounded-full after:bg-slate-300 after:transition-all after:duration-200 peer-checked:after:translate-x-5 peer-checked:after:bg-slate-900"></div>
                                            <span class="ml-3 text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-slate-200 transition-colors">Save credentials</span>
                                        </label>
                                    </div>
                                </div>

                                <div class="glass-panel rounded-[2rem] p-4 sm:p-5 flex items-center justify-between gap-4">
                                    <div>
                                        <p class="text-[10px] font-black uppercase tracking-[0.24em] text-slate-500">Ready To Login</p>
                                        <p class="text-xs font-bold text-slate-300 mt-2">Enter your details and continue to your dashboard.</p>
                                    </div>
                                    <div class="w-12 h-12 rounded-2xl bg-amber-400/10 border border-amber-300/20 flex items-center justify-center text-amber-300 shrink-0">
                                        <i class="fas fa-arrow-right-to-bracket"></i>
                                    </div>
                                </div>

                                <button type="submit"
                                    class="w-full btn-gradient text-slate-900 py-4.5 px-6 rounded-2xl font-black text-xs uppercase tracking-[0.2em] hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl shadow-yellow-500/10">
                                    Sign In
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <button
        type="button"
        id="auth-scroll-top-button"
        class="fixed bottom-5 right-4 sm:bottom-6 sm:right-6 inline-flex h-12 w-12 items-center justify-center rounded-2xl border border-amber-300/20 bg-amber-400 text-slate-900 shadow-xl shadow-yellow-500/20 opacity-0 pointer-events-none translate-y-4 transition-all duration-200 hover:scale-105"
        aria-label="Scroll to top"
    >
        <i class="fas fa-arrow-up text-sm"></i>
    </button>

    <script>
        function copyResetLink() {
            const el = document.getElementById('reset_link');
            if (!el) return;
            el.select();
            el.setSelectionRange(0, el.value.length);
            try {
                document.execCommand('copy');
            } catch (e) {}
        }

        (function () {
            const loader = document.getElementById('auth-page-loader');
            const loaderText = document.getElementById('auth-page-loader-text');
            const loaderSubtext = document.getElementById('auth-page-loader-subtext');

            const showLoader = function (title, description) {
                if (!loader) return;
                if (loaderText && title) loaderText.textContent = title;
                if (loaderSubtext && description) loaderSubtext.textContent = description;
                loader.classList.remove('is-hidden');
            };

            const hideLoader = function () {
                if (!loader) return;
                loader.classList.add('is-hidden');
            };

            const shouldShowForLink = function (link) {
                if (!link) return false;
                const href = (link.getAttribute('href') || '').trim();
                if (!href || href === '#' || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return false;
                if (href.startsWith('#') || link.hasAttribute('download') || (link.target && link.target !== '_self')) return false;
                return true;
            };

            window.addEventListener('load', function () {
                window.setTimeout(hideLoader, 120);
            });

            window.addEventListener('pageshow', hideLoader);

            document.addEventListener('click', function (event) {
                const link = event.target.closest('a');
                if (!shouldShowForLink(link)) return;
                showLoader('Loading Page', 'Please wait while the next page opens.');
            });

            document.addEventListener('submit', function (event) {
                if (!(event.target instanceof HTMLFormElement)) return;
                showLoader('Loading', 'Processing your request...');
            });
        })();

        (function () {
            const loginType = document.getElementById('login_type');
            const login = document.getElementById('login');
            const remember = document.getElementById('remember');
            if (!loginType || !login || !remember) return;

            const storageKey = 'ag_login_saved';
            try {
                const saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
                if (saved && typeof saved === 'object') {
                    if (saved.login_type) loginType.value = saved.login_type;
                    if (saved.login) login.value = saved.login;
                    remember.checked = true;
                }
            } catch (e) {}

            const save = () => {
                if (!remember.checked) {
                    localStorage.removeItem(storageKey);
                    return;
                }
                localStorage.setItem(storageKey, JSON.stringify({
                    login_type: loginType.value || '',
                    login: login.value || ''
                }));
            };

            remember.addEventListener('change', save);
            loginType.addEventListener('change', save);
            login.addEventListener('input', save);
        })();

        (function () {
            const scrollTopButton = document.getElementById('auth-scroll-top-button');
            if (!scrollTopButton) return;

            const syncScrollTopButton = function () {
                const shouldShow = window.scrollY > 220;
                scrollTopButton.classList.toggle('opacity-0', !shouldShow);
                scrollTopButton.classList.toggle('pointer-events-none', !shouldShow);
                scrollTopButton.classList.toggle('translate-y-4', !shouldShow);
            };

            window.addEventListener('scroll', syncScrollTopButton, { passive: true });
            scrollTopButton.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
            syncScrollTopButton();
        })();
    </script>
</body>
</html>
