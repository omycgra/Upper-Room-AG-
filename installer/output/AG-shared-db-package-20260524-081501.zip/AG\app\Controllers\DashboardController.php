<?php

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../Models/Member.php';
require_once __DIR__ . '/../Models/Visitor.php';
require_once __DIR__ . '/../Models/Attendance.php';
require_once __DIR__ . '/../Models/Finance.php';
require_once __DIR__ . '/../Models/Department.php';

class DashboardController extends BaseController {
    public function index() {
        $cacheTtl = 90; // seconds
        $currentUserId = (int)(Session::get('user_id') ?? 0);
        $currentRole = (string)(Session::get('user_role') ?? 'guest');
        $cacheKey = 'dashboard_cache_' . $currentRole . '_' . $currentUserId;
        $cached = Session::get($cacheKey);
        if (is_array($cached) && isset($cached['generated_at'], $cached['payload'])) {
            $age = time() - (int)$cached['generated_at'];
            if ($age >= 0 && $age <= $cacheTtl) {
                View::render('dashboard.index', $cached['payload']);
                return;
            }
        }

        $memberModel = new Member();
        $visitorModel = new Visitor();
        $attendanceModel = new Attendance();
        $financeModel = new Finance();
        $deptModel = new Department();

        $memberStats = $memberModel->getStats();
        $isDeptHead = Auth::isDepartmentHead();
        $isStaff = Auth::isStaff();
        $isVisitationTeam = Auth::isVisitationTeam();
        $myDeptId = $isDeptHead ? (int)(Session::get('user_department_id') ?? 0) : 0;
        $deptContext = null;
        $staffContext = null;
        $visitationContext = null;
        $visitorInsights = null;

        if ($isStaff) {
            $allowedTypes = ['Offering', 'Tithe', 'Departmental Savings', 'Welfare'];
            $staffSummary = $financeModel->getRecorderTotals((int)Session::get('user_id'), date('m'), date('Y'), $allowedTypes);
            $staffTransactions = $financeModel->getRecentTransactionsByRecorderWithMeta((int)Session::get('user_id'), 12, $allowedTypes);
            $staffContext = [
                'summary' => $staffSummary,
                'transactions' => $staffTransactions,
                'allowed_types' => $allowedTypes,
                'month_label' => date('F Y')
            ];
        }

        if ($isVisitationTeam) {
            $assignedVisitors = $visitorModel->getVisitationAssignments();
            $pending = 0;
            $completed = 0;
            $firstTime = 0;
            $scheduled = 0;

            foreach ($assignedVisitors as $visitor) {
                if (($visitor['follow_up_status'] ?? '') === 'Completed') {
                    $completed++;
                } else {
                    $pending++;
                }

                if (!empty($visitor['is_first_time'])) {
                    $firstTime++;
                }

                if (!empty($visitor['follow_up_date'])) {
                    $scheduled++;
                }
            }

            $visitationContext = [
                'visitors' => $assignedVisitors,
                'summary' => [
                    'assigned_total' => count($assignedVisitors),
                    'pending_total' => $pending,
                    'completed_total' => $completed,
                    'first_time_total' => $firstTime,
                    'scheduled_total' => $scheduled,
                ],
            ];
        }

        if (!$isStaff && $isDeptHead && $myDeptId > 0) {
            $db = Database::getInstance();
            $dept = $deptModel->find($myDeptId);
            $deptMembers = $db->fetchAll(
                "SELECT id, first_name, last_name, phone, photo_path
                 FROM members
                 WHERE department_id = ?
                 ORDER BY first_name ASC, last_name ASC",
                [$myDeptId]
            );

            $month = (int)date('m');
            $year = (int)date('Y');
            $deptIncome = $financeModel->getMonthlyIncome($month, $year, $myDeptId, null);
            $deptExpenses = $financeModel->getMonthlyExpenses($month, $year, $myDeptId, null);
            $deptBalance = $deptIncome - $deptExpenses;
            $deptTx = $financeModel->getRecentDepartmentTransactionsWithMeta($myDeptId, 15, null);

            $deptContext = [
                'department' => $dept,
                'members' => $deptMembers,
                'month_label' => date('F Y'),
                'income' => $deptIncome,
                'expenses' => $deptExpenses,
                'net' => $deptBalance,
                'transactions' => $deptTx
            ];
        }

        if (!$isDeptHead && !$isStaff && !$isVisitationTeam) {
            $allVisitors = $visitorModel->getAllWithAssignee();
            $recentVisitors = array_slice($allVisitors, 0, 5);
            $today = date('Y-m-d');
            $currentMonth = date('Y-m');
            $visitorSummary = [
                'total' => count($allVisitors),
                'pending' => 0,
                'completed' => 0,
                'first_time' => 0,
                'today' => 0,
                'this_month' => 0,
            ];

            foreach ($allVisitors as $visitor) {
                $visitDate = (string)($visitor['visit_date'] ?? '');
                if (($visitor['follow_up_status'] ?? '') === 'Completed') {
                    $visitorSummary['completed']++;
                } else {
                    $visitorSummary['pending']++;
                }

                if (!empty($visitor['is_first_time'])) {
                    $visitorSummary['first_time']++;
                }

                if ($visitDate === $today) {
                    $visitorSummary['today']++;
                }

                if ($visitDate !== '' && strpos($visitDate, $currentMonth) === 0) {
                    $visitorSummary['this_month']++;
                }
            }

            $visitorInsights = [
                'summary' => $visitorSummary,
                'recent' => $recentVisitors,
            ];
        }

        $data = [
            'title' => 'Dashboard Overview',
            'isDeptHead' => $isDeptHead,
            'isStaff' => $isStaff,
            'isVisitationTeam' => $isVisitationTeam,
            'dept' => $deptContext,
            'staff' => $staffContext,
            'visitation' => $visitationContext,
            'visitorInsights' => $visitorInsights,
            'stats' => [
                'total_members' => $memberStats['total'],
                'recent_growth' => $memberStats['new'],
                'attendance_rate' => $attendanceModel->getAttendanceRate(),
                'monthly_donations' => '$' . number_format($financeModel->getMonthlyTotal(), 2),
                'birthday_count' => $memberModel->getBirthdayCountThisMonth()
            ],
            'birthdays' => $memberModel->getUpcomingBirthdays(10),
            'demographics' => [
                'gender' => $memberModel->getGenderDistribution(),
                'age' => $memberModel->getAgeDistribution()
            ]
        ];

        Session::set($cacheKey, [
            'generated_at' => time(),
            'payload' => $data
        ]);
        
        View::render('dashboard.index', $data);
    }

    public function birthdaysThisMonth() {
        $memberModel = new Member();
        $birthdays = $memberModel->getBirthdaysThisMonth();

        header('Content-Type: application/json');
        echo json_encode([
            'count' => count($birthdays),
            'birthdays' => $birthdays
        ]);
        exit;
    }
}
