<?php

class BaseController {
    public function __construct() {
        $currentRoute = trim($_SERVER['REQUEST_URI'] ?? '', '/');
        $scriptName = trim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/');
        if ($scriptName && strpos($currentRoute, $scriptName) === 0) {
            $currentRoute = trim(substr($currentRoute, strlen($scriptName)), '/');
        }
        if (($pos = strpos($currentRoute, '?')) !== false) {
            $currentRoute = substr($currentRoute, 0, $pos);
        }

        $publicRoutes = [
            'attendance/quick',
            'attendance/quickMark'
        ];

        if (!Auth::check() && !in_array($currentRoute, $publicRoutes, true)) {
            header('Location: login');
            exit;
        }

        try {
            $db = Database::getInstance();
            $userId = (int)Session::get('user_id');
            if ($userId > 0) {
                if (!$db->columnExists('users', 'last_activity_at')) {
                    $db->query("ALTER TABLE users ADD COLUMN last_activity_at " . ($db->isPgsql() ? 'TIMESTAMP' : 'DATETIME') . " NULL");
                }
                $lastPing = (int)Session::get('last_activity_ping', 0);
                $now = time();
                if ($lastPing <= 0 || ($now - $lastPing) >= 30) {
                    $db->query("UPDATE users SET last_activity_at = NOW() WHERE id = ?", [$userId]);
                    $row = $db->fetch("SELECT photo_path, permissions_json FROM users WHERE id = ? LIMIT 1", [$userId]);
                    $photoPath = trim((string)($row['photo_path'] ?? ''));
                    $sessionPhoto = trim((string)Session::get('user_photo', ''));
                    if ($photoPath !== $sessionPhoto) {
                        Session::set('user_photo', $photoPath !== '' ? $photoPath : null);
                    }
                    $rawPerms = (string)($row['permissions_json'] ?? '');
                    $sessionRawPerms = (string)Session::get('user_permissions_json', '');
                    if ($rawPerms !== $sessionRawPerms) {
                        Session::set('user_permissions_json', $rawPerms);
                        $decoded = json_decode(trim((string)$rawPerms), true);
                        if (!is_array($decoded)) $decoded = [];
                        $out = [];
                        foreach ($decoded as $v) {
                            $s = trim((string)$v);
                            if ($s !== '') $out[] = $s;
                        }
                        Session::set('user_permissions', array_values(array_unique($out)));
                    }
                    Session::set('last_activity_ping', $now);
                }
            }
        } catch (Throwable $e) {
        }

        $currentRoute = $this->resolveCurrentRoute();

        if (Auth::isAuditor()) {
            $allowed = [
                'auditor',
                'reports',
                'reports/download',
                'transactions',
                'transactions/download',
                'department-savings',
                'department-savings/download',
                'finance/downloadExpenses',
                'logout'
            ];
            $this->guardRoute($currentRoute, $allowed);
        }

        if (Auth::isDepartmentHead()) {
            $allowed = [
                'dashboard',
                'logout',
                'members',
                'members/viewAjax',
                'finance',
                'transactions',
                'transactions/download',
                'department-savings',
                'department-savings/download',
                'attendance/department',
                'attendance/download',
                'finance/memberSummary',
                'finance/memberTransactions',
                'finance/requestDepartmentExpense',
                'finance/myRequestUpdates',
                'finance/updateBankDetails',
                'chat/threads',
                'chat/messages',
                'chat/send',
                'chat/delete',
                'chat/clear'
            ];
            $this->guardRoute($currentRoute, $allowed);
        }

        if (Auth::isStaff()) {
            $allowed = [
                'dashboard',
                'logout',
                'finance',
                'transactions',
                'transactions/download',
                'department-savings',
                'department-savings/download',
                'finance/add',
                'finance/store',
                'finance/requestChange',
                'finance/updateTransaction',
                'finance/downloadExpenses',
                'sms',
                'sms/balance',
                'sms/send',
                'debug/sms-logs',
                'chat/threads',
                'chat/messages',
                'chat/send',
                'chat/delete',
                'chat/clear'
            ];
            $allowed[] = 'finance/myRequestUpdates';
            if (Auth::isFinanceHead()) {
                $allowed[] = 'finance/approveChangeRequest';
                $allowed[] = 'finance/rejectChangeRequest';
                $allowed[] = 'finance/approveDepartmentExpenseRequest';
                $allowed[] = 'finance/rejectDepartmentExpenseRequest';
                $allowed[] = 'finance/pendingApprovals';
                $allowed[] = 'reports';
                $allowed[] = 'reports/download';
            }
            $this->guardRoute($currentRoute, $allowed);
        }

        if (Auth::isVisitationTeam()) {
            $allowed = [
                'dashboard',
                'logout',
                'attendance/view',
                'attendance/download',
                'visitors',
                'visitors/details',
                'visitors/approve',
                'visitors/export',
                'chat/threads',
                'chat/messages',
                'chat/send',
                'chat/delete',
                'chat/clear'
            ];
            $this->guardRoute($currentRoute, $allowed);
        }

        if (Auth::isPastor()) {
            $allowed = [
                'pastor',
                'logout',
                'members',
                'members/viewAjax',
                'visitors',
                'visitors/details',
                'visitors/assign',
                'attendance/view',
                'attendance/download',
                'transactions',
                'transactions/download',
                'department-savings',
                'department-savings/download',
                'finance/approveDepartmentExpenseRequest',
                'finance/rejectDepartmentExpenseRequest',
                'reports',
                'reports/download',
                'chat/threads',
                'chat/messages',
                'chat/send',
                'chat/delete',
                'chat/clear'
            ];
            $this->guardRoute($currentRoute, $allowed);
        }
    }

    protected function isAdmin() {
        if (!Auth::isAdmin()) {
            Session::flash('error', 'Unauthorized access. Admins only.');
            header('Location: dashboard');
            exit;
        }
    }

    protected function renderPlaceholder($title) {
        $data = [
            'title' => $title,
            'content' => '<div class="bg-white p-8 rounded-xl shadow-sm text-center">
                <i class="fas fa-tools text-6xl text-gray-300 mb-4"></i>
                <h2 class="text-2xl font-bold text-gray-800">' . $title . ' Module</h2>
                <p class="text-gray-500 mt-2">This module is currently under development.</p>
                <a href="dashboard" class="mt-6 inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">Back to Dashboard</a>
            </div>'
        ];
        
        // We bypass the View::render slightly here to show a quick placeholder
        // or we can create a placeholder view file.
        // Let's create a placeholder view file instead for consistency.
        View::render('placeholder', $data);
    }

    private function resolveCurrentRoute() {
        $currentRoute = trim($_SERVER['REQUEST_URI'], '/');
        $scriptName = trim(dirname($_SERVER['SCRIPT_NAME']), '/');
        if ($scriptName && strpos($currentRoute, $scriptName) === 0) {
            $currentRoute = trim(substr($currentRoute, strlen($scriptName)), '/');
        }
        if (($pos = strpos($currentRoute, '?')) !== false) {
            $currentRoute = substr($currentRoute, 0, $pos);
        }

        return $currentRoute === '' ? $this->resolveHomeRoute() : $currentRoute;
    }

    private function resolveHomeRoute(): string {
        if (Auth::isAuditor()) return 'auditor';
        if (Auth::isPastor()) return 'pastor';
        return 'dashboard';
    }

    private function guardRoute($currentRoute, array $allowed) {
        if (!in_array($currentRoute, $allowed, true) && !Auth::hasPermission($currentRoute)) {
            Session::flash('error', 'Unauthorized access.');
            header('Location: ' . $this->resolveHomeRoute());
            exit;
        }
    }
}
